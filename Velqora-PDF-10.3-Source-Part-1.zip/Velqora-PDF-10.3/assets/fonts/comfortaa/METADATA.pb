name: "Comfortaa"
designer: "Johan Aakerlund"
license: "OFL"
category: "DISPLAY"
date_added: "2011-08-10"
fonts {
  name: "Comfortaa"
  style: "normal"
  weight: 400
  filename: "Comfortaa[wght].ttf"
  post_script_name: "Comfortaa-Regular"
  full_name: "Comfortaa Regular"
  copyright: "Copyright 2011 The Comfortaa Project Authors (https://github.com/alexeiva/comfortaa), with Reserved Font Name \"Comfortaa\"."
}
subsets: "cyrillic"
subsets: "cyrillic-ext"
subsets: "greek"
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
subsets: "vietnamese"
axes {
  tag: "wght"
  min_value: 300.0
  max_value: 700.0
}
source {
  repository_url: "https://github.com/alexeiva/comfortaa"
  commit: "4aa21cfb7b018629dcf17aab6220e638411c7164"
}
stroke: "SANS_SERIF"
classifications: "DISPLAY"
