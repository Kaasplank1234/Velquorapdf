name: "Pacifico"
designer: "Vernon Adams, Jacques Le Bailly, Botjo Nikoltchev, Ani Petrova"
license: "OFL"
category: "HANDWRITING"
date_added: "2011-03-09"
fonts {
  name: "Pacifico"
  style: "normal"
  weight: 400
  filename: "Pacifico-Regular.ttf"
  post_script_name: "Pacifico-Regular"
  full_name: "Pacifico Regular"
  copyright: "Copyright 2018 The Pacifico Project Authors (https://github.com/googlefonts/Pacifico)"
}
subsets: "cyrillic"
subsets: "cyrillic-ext"
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
subsets: "vietnamese"
source {
  repository_url: "https://github.com/googlefonts/Pacifico"
  commit: "aff5d08efd4883cd58a660b4b688a73edcea3d92"
}
