name: "News Cycle"
designer: "Nathan Willis"
license: "OFL"
category: "SANS_SERIF"
date_added: "2011-04-27"
fonts {
  name: "News Cycle"
  style: "normal"
  weight: 400
  filename: "NewsCycle-Regular.ttf"
  post_script_name: "NewsCycle"
  full_name: "News Cycle"
  copyright: "Copyright (c) 2010-2011, Nathan Willis (nwillis@glyphography.com), with Reserved Font Name \"News Cycle.\""
}
fonts {
  name: "News Cycle"
  style: "normal"
  weight: 700
  filename: "NewsCycle-Bold.ttf"
  post_script_name: "NewsCycle-Bold"
  full_name: "News Cycle Bold"
  copyright: "Copyright (c) 2010-2011, Nathan Willis (nwillis@glyphography.com), with Reserved Font Name \"News Cycle.\""
}
subsets: "menu"
subsets: "cyrillic"
subsets: "cyrillic-ext"
subsets: "greek"
subsets: "greek-ext"
subsets: "latin"
subsets: "vietnamese"
subsets: "latin-ext"
source {
  repository_url: "https://github.com/googlefonts/googlefontdirectory-hg"
  commit: "52f780bc9d197280a9f430574e179a5f233c56b6"
}
