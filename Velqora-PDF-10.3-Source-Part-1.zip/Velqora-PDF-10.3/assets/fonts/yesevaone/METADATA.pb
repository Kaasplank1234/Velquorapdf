name: "Yeseva One"
designer: "Jovanny Lemonad"
license: "OFL"
category: "DISPLAY"
date_added: "2011-07-13"
fonts {
  name: "Yeseva One"
  style: "normal"
  weight: 400
  filename: "YesevaOne-Regular.ttf"
  post_script_name: "YesevaOne-Regular"
  full_name: "Yeseva One Regular"
  copyright: "Copyright 2012 The Yeseva One Project Authors (lemonad@jovanny.ru), with Reserved Font Name \"Yeseva\"."
}
subsets: "cyrillic"
subsets: "cyrillic-ext"
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
subsets: "vietnamese"
stroke: "SERIF"
classifications: "DISPLAY"
source {
  repository_url: "https://github.com/alexeiva/yesevaone"
  commit: "0d609f6155ed0fe1d822696135ffbd04b88fd017"
}
