name: "Catamaran"
designer: "Pria Ravichandran"
license: "OFL"
category: "SANS_SERIF"
date_added: "2015-07-08"
fonts {
  name: "Catamaran"
  style: "normal"
  weight: 400
  filename: "Catamaran[wght].ttf"
  post_script_name: "Catamaran-Thin"
  full_name: "Catamaran Thin"
  copyright: "Copyright 2020 The Catamaran Project Authors (https://github.com/VanillaandCream/Catamaran-Tamil)"
}
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
subsets: "tamil"
axes {
  tag: "wght"
  min_value: 100.0
  max_value: 900.0
}
source {
  repository_url: "https://github.com/VanillaandCream/Catamaran-Tamil"
  commit: "7559b4906f9c9148fb22c6f89508c3053a78a296"
}
primary_script: "Taml"
