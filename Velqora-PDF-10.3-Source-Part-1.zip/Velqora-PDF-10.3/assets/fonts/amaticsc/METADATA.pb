name: "Amatic SC"
designer: "Vernon Adams, Ben Nathan, Thomas Jockin"
license: "OFL"
category: "HANDWRITING"
date_added: "2011-10-12"
fonts {
  name: "Amatic SC"
  style: "normal"
  weight: 400
  filename: "AmaticSC-Regular.ttf"
  post_script_name: "AmaticSC-Regular"
  full_name: "Amatic SC Regular"
  copyright: "Copyright 2015 The Amatic SC Project Authors (https://github.com/googlefonts/AmaticSC)"
}
fonts {
  name: "Amatic SC"
  style: "normal"
  weight: 700
  filename: "AmaticSC-Bold.ttf"
  post_script_name: "AmaticSC-Bold"
  full_name: "Amatic SC Bold"
  copyright: "Copyright 2015 The Amatic SC Project Authors (https://github.com/googlefonts/AmaticSC)"
}
subsets: "cyrillic"
subsets: "hebrew"
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
subsets: "vietnamese"
source {
  repository_url: "https://github.com/googlefonts/AmaticSC"
  commit: "308846136d2dcfb6aef2160d7e927698cdaf9c05"
  config_yaml: "sources/config.yaml"
}
stroke: "SANS_SERIF"
classifications: "DISPLAY"
