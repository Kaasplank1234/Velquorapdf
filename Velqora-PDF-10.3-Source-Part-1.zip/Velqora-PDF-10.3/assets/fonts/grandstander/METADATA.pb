name: "Grandstander"
designer: "Tyler Finck, ETC"
license: "OFL"
category: "DISPLAY"
date_added: "2020-07-24"
fonts {
  name: "Grandstander"
  style: "normal"
  weight: 400
  filename: "Grandstander[wght].ttf"
  post_script_name: "Grandstander-Thin"
  full_name: "Grandstander Thin"
  copyright: "Copyright 2020 The Grandstander Project Authors (https://github.com/Etcetera-Type-Co/Grandstander)"
}
fonts {
  name: "Grandstander"
  style: "italic"
  weight: 400
  filename: "Grandstander-Italic[wght].ttf"
  post_script_name: "Grandstander-ThinItalic"
  full_name: "Grandstander Thin Italic"
  copyright: "Copyright 2020 The Grandstander Project Authors (https://github.com/Etcetera-Type-Co/Grandstander)"
}
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
subsets: "vietnamese"
axes {
  tag: "wght"
  min_value: 100.0
  max_value: 900.0
}
source {
  repository_url: "https://github.com/Etcetera-Type-Co/Grandstander"
  commit: "33c288495d8ac7bc0b29a9f35801de1df7e6d010"
}
minisite_url: "https://etceteratype.co/grandstander"
classifications: "DISPLAY"
classifications: "HANDWRITING"
