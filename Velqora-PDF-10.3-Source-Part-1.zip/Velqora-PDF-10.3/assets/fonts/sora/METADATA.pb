name: "Sora"
designer: "Jonathan Barnbrook, Julián Moncada"
license: "OFL"
category: "SANS_SERIF"
date_added: "2020-06-10"
fonts {
  name: "Sora"
  style: "normal"
  weight: 400
  filename: "Sora[wght].ttf"
  post_script_name: "Sora-Regular"
  full_name: "Sora Regular"
  copyright: "Copyright 2019 The Sora Project Authors (https://github.com/sora-xor/sora-font)"
}
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
axes {
  tag: "wght"
  min_value: 100.0
  max_value: 800.0
}
source {
  repository_url: "https://github.com/sora-xor/sora-font"
  commit: "7f9a9c5d0ccd1c099cfac420aa27133df1c5fdc4"
}
