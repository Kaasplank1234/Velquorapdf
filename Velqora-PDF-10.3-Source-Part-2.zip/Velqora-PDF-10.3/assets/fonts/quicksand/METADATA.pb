name: "Quicksand"
designer: "Andrew Paglinawan"
license: "OFL"
category: "SANS_SERIF"
date_added: "2011-10-19"
fonts {
  name: "Quicksand"
  style: "normal"
  weight: 400
  filename: "Quicksand[wght].ttf"
  post_script_name: "Quicksand-Light"
  full_name: "Quicksand Light"
  copyright: "Copyright 2019 The Quicksand Project Authors (https://github.com/andrew-paglinawan/QuicksandFamily.git), with Reserved Font Name \"Quicksand\""
}
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
subsets: "vietnamese"
axes {
  tag: "wght"
  min_value: 300.0
  max_value: 700.0
}
source {
  repository_url: "https://github.com/ThomasJockin/QuicksandFamily"
  commit: "02ead1c009102a433b9cd155f611df1e5f49bd9c"
  files {
    source_file: "fonts/variable/Quicksand[wght].ttf"
    dest_file: "Quicksand[wght].ttf"
  }
  branch: "master"
}
