name: "Fredoka"
designer: "Milena Brandão, Hafontia"
license: "OFL"
category: "SANS_SERIF"
date_added: "2021-12-15"
fonts {
  name: "Fredoka"
  style: "normal"
  weight: 400
  filename: "Fredoka[wdth,wght].ttf"
  post_script_name: "Fredoka-Light"
  full_name: "Fredoka Light"
  copyright: "Copyright 2016 The Fredoka Project Authors (https://github.com/hafontia/Fredoka-One)"
}
subsets: "hebrew"
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
axes {
  tag: "wdth"
  min_value: 75.0
  max_value: 125.0
}
axes {
  tag: "wght"
  min_value: 300.0
  max_value: 700.0
}
source {
  repository_url: "https://github.com/hafontia-zz/Fredoka-One"
  commit: "35c584ff23450c9bcdf8819706e12fcdeefe1712"
  files {
    source_file: "OFL.txt"
    dest_file: "OFL.txt"
  }
  files {
    source_file: "fonts/variable/Fredoka[wdth,wght].ttf"
    dest_file: "Fredoka[wdth,wght].ttf"
  }
  branch: "gh-pages"
  config_yaml: "sources/config.yml"
}
