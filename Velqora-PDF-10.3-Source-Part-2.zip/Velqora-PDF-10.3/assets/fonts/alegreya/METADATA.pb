name: "Alegreya"
designer: "Juan Pablo del Peral, HT Fonts"
license: "OFL"
category: "SERIF"
date_added: "2011-12-19"
fonts {
  name: "Alegreya"
  style: "normal"
  weight: 400
  filename: "Alegreya[wght].ttf"
  post_script_name: "Alegreya-Regular"
  full_name: "Alegreya Regular"
  copyright: "Copyright 2011 The Alegreya Project Authors (https://github.com/huertatipografica/Alegreya)"
}
fonts {
  name: "Alegreya"
  style: "italic"
  weight: 400
  filename: "Alegreya-Italic[wght].ttf"
  post_script_name: "Alegreya-Italic"
  full_name: "Alegreya Italic"
  copyright: "Copyright 2011 The Alegreya Project Authors (https://github.com/huertatipografica/Alegreya)"
}
subsets: "cyrillic"
subsets: "cyrillic-ext"
subsets: "greek"
subsets: "greek-ext"
subsets: "latin"
subsets: "latin-ext"
subsets: "menu"
subsets: "vietnamese"
axes {
  tag: "wght"
  min_value: 400.0
  max_value: 900.0
}
source {
  repository_url: "https://github.com/huertatipografica/Alegreya"
  commit: "1dd6b28b57c50e3168db1cbbb8086e7978abcfbf"
  files {
    source_file: "OFL.txt"
    dest_file: "OFL.txt"
  }
  files {
    source_file: "fonts/variable/Alegreya[wght].ttf"
    dest_file: "Alegreya[wght].ttf"
  }
  files {
    source_file: "fonts/variable/Alegreya-Italic[wght].ttf"
    dest_file: "Alegreya-Italic[wght].ttf"
  }
  branch: "master"
}
minisite_url: "https://htfonts.com/en/fonts/alegreya"
