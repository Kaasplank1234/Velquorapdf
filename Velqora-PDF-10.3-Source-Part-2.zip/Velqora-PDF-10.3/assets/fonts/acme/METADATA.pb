name: "Acme"
designer: "Juan Pablo del Peral, HT Fonts"
license: "OFL"
category: "SANS_SERIF"
date_added: "2011-12-19"
source {
  repository_url: "https://github.com/googlefonts/acme"
  commit: "33ccde2d61442c1f6c09125ba26fe4ff0ccee834"
  files {
    source_file: "OFL.txt"
    dest_file: "OFL.txt"
  }
  files {
    source_file: "fonts/ttf/Acme-Regular.ttf"
    dest_file: "Acme-Regular.ttf"
  }
  branch: "master"
  config_yaml: "sources/config.yaml"
}

fonts {
  name: "Acme"
  style: "normal"
  weight: 400
  filename: "Acme-Regular.ttf"
  post_script_name: "Acme-Regular"
  full_name: "Acme Regular"
  copyright: "Copyright (c) 2011 by Juan Pablo del Peral (info@htfonts.com), with Reserved Font Name \"Acme\""
}
subsets: "latin"
subsets: "menu"
stroke: "SANS_SERIF"
classifications: "DISPLAY"
