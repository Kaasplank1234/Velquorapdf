# Velqora PDF 10.3 — Source Distribution

This archive combines the provided Velqora PDF source archives into a single package, including the Linux packaging scripts and bundled font assets. The source files and build scripts are preserved without modification.

## Licensing

The supplied `LICENSE` contains the GNU Affero General Public License, version 3. The supplied `README.md` states `AGPL-3.0-or-later`. See `THIRD_PARTY.md` and the license notices inside `assets/fonts/` and `assets/tessdata/` for third-party terms. Review all license and attribution requirements before public distribution.

## Layout

- `src/` — Python application source
- `tests/` — tests
- `scripts/` — build and verification scripts
- `.github/workflows/` — automation
- `linux-build/` — Linux packaging scripts and build configuration
- `assets/` — images, OCR data, and fonts (with accompanying license files)
- `requirements*.txt` — Python dependencies
- `LICENSE` — AGPL license
- `README.md`, `START_HERE.md` — original project documentation

## Version notice

The supplied README and some build files refer to earlier releases (including version 3.0). They have been preserved as provided, and should be reviewed and updated before publishing this package as a fully verified 10.3 source release. No build or runtime verification has been performed on this merged archive.

## Before publishing

Check the code, automation configuration, asset redistribution rights, copyright notices, and version references. Publishing this archive makes the included source files and assets publicly accessible.
